import java.util.*;
public class remove{
   public static void main(String args[]){
      ArrayList<String> alist=new ArrayList<String>(); 
      alist.add("hi");
      alist.add("hello");
      alist.add("welcome");
      alist.add("to");
      alist.add("java");
      alist.add("language");
      System.out.println(alist);
      alist.remove("hi");
      alist.remove("language");
      System.out.println(alist);
      alist.remove(2);
      System.out.println(alist);
   }
}
