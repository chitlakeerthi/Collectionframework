import java.util.*; 
public class changing{ 
    public static void main(String args[]) 
    { 
 
        Map<Integer, String> hm1 
            = new HashMap<Integer, String>();  
        hm1.put(new Integer(1), "hi"); 
        hm1.put(new Integer(2), "hi"); 
        hm1.put(new Integer(3), "welcome"); 
  
        System.out.println("Initial Map " + hm1); 
  
        hm1.put(new Integer(2), "hello"); 
  
        System.out.println("Updated Map " + hm1); 
    } 
} 
