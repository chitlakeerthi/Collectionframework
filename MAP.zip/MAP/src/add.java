import java.util.*; 
public class add { 
    public static void main(String args[]) 
    { 
        Map<Integer, String> hm1 = new HashMap<>(); 
        Map<Integer, String> hm2 
            = new HashMap<Integer, String>(); 
        hm1.put(1, "hi"); 
        hm1.put(2, "hello"); 
        hm1.put(3, "welcome"); 
  
        hm2.put(new Integer(1), "one"); 
        hm2.put(new Integer(2), "two"); 
        hm2.put(new Integer(3), "three"); 
        System.out.println(hm1); 
        System.out.println(hm2); 
    } 
} 
