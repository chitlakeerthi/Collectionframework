import java.util.*; 
public class remove{ 
  
    public static void main(String args[]) 
    { 
        Map<Integer, String> hm1 
            = new HashMap<Integer, String>(); 
        hm1.put(new Integer(1), "hi"); 
        hm1.put(new Integer(2), "hello"); 
        hm1.put(new Integer(4), "to"); 
        hm1.put(new Integer(3), "school"); 
        System.out.println(hm1); 
        hm1.remove(new Integer(4));
        System.out.println(hm1); 
    } 
} 