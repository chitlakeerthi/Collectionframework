import java.util.*; 
  
public class add { 
    public static void main(String[] args) 
        throws IllegalStateException 
    { 
        Queue<Integer> Q 
            = new LinkedList<Integer>(); 
        Q.add(123); 
        Q.add(345); 
        Q.add(1234); 
        Q.add(111); 
        System.out.println("Queue: " + Q); 
    } 
}