import java.util.*; 
  
public class remove { 
    public static void main(String[] args) 
        throws IllegalStateException 
    { 
        Queue<Integer> Q 
            = new LinkedList<Integer>();  
        Q.add(123); 
        Q.add(456); 
        Q.add(111); 
        Q.add(222);
        System.out.println("Queue: " + Q);  
        System.out.println("Queue's head: " + Q.remove()); 
        System.out.println("Queue's head: " + Q.remove()); 
    } 
} 