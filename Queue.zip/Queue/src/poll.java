import java.util.*; 
  
public class poll { 
    public static void main(String[] args) 
        throws IllegalStateException 
    { 
        Queue<Integer> Q 
            = new LinkedList<Integer>(); 
        Q.add(123); 
        Q.add(345); 
        Q.add(567); 
        Q.add(456); 
        System.out.println("Queue: " + Q); 
        System.out.println("Queue's head: " + Q.poll()); 
        System.out.println("Queue's head: " + Q.poll());
       
    } 
} 