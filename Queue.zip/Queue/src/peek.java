import java.util.*; 
  
public class peek { 
    public static void main(String[] args) 
        throws IllegalStateException 
    { 
   
        Queue<Integer> Q 
            = new LinkedList<Integer>(); 
        Q.add(111); 
        Q.add(222); 
        Q.add(333); 
        Q.add(444); 
        System.out.println("Queue: " + Q);
        System.out.println("Queue's head: " + Q.peek()); 
        System.out.println("Queue: " + Q); 
    } 
} 