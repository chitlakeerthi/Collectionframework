
import java.util.LinkedList; 
  
public class size1 { 
    public static void main(String args[]) 
    { 
  
        LinkedList<String> list = new LinkedList<String>(); 
  
        list.add("hi"); 
        list.add("hello"); 
        list.add("welcome"); 
        list.add("1"); 
        list.add("2"); 
  
        System.out.println("LinkedList:" + list); 
          
        System.out.println("The size of the linked list is: " 
                                                + list.size()); 
    } 
} 
