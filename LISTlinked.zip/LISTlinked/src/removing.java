import java.util.*;
public class removing{
   public static void main(String args[]){

      LinkedList<String> list=new LinkedList<String>();
      list.add("hi");
      list.add("hello");
      list.add("welcome");
      list.add("to");
      list.add("java");
      list.removeFirst();
      list.removeLast();
      Iterator<String> iterator=list.iterator();
      while(iterator.hasNext()){
         System.out.print(iterator.next()+" ");
      }
      list.remove(1);
      System.out.print("\nAfter removing second element: ");
      Iterator<String> iterator2=list.iterator();
      while(iterator2.hasNext()){
         System.out.print(iterator2.next()+" ");
      }
   }
}