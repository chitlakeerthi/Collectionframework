
import java.util.*;
public class adding{
   public static void main(String args[]){

     LinkedList<String> list=new LinkedList<String>();
     list.add("Seetha");
     list.add("geetha");
     list.add("Ram");
     list.addFirst("hi");
     list.addLast("hello");
     list.add(3, "ok");
     Iterator<String> iterator=list.iterator();
     while(iterator.hasNext()){
       System.out.println(iterator.next());
     }
   } 
} 