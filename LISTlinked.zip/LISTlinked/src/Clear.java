
import java.util.LinkedList; 
  
public class Clear { 
    public static void main(String args[]) 
    { 
   
        LinkedList<String> list = new LinkedList<String>(); 
        list.add("hi"); 
        list.add("hello"); 
        list.add("welcome"); 
        list.add("1"); 
        list.add("2"); 
        System.out.println("Original LinkedList:" + list); 
        list.clear(); 
        System.out.println("List after clearing all elements: " + list); 
        list.add("hello"); 
        list.add("hi"); 
        list.add("java");
        System.out.println("After adding elements to empty list:" + list); 
    } 
} 
