 
import java.util.HashSet; 
  
public class remove{ 
    public static void main(String args[]) 
    {
        HashSet<String> set = new HashSet<String>(); 
  
        set.add("hello"); 
        set.add("To"); 
        set.add("java"); 
        set.add("4"); 
        set.add("hi"); 
        System.out.println("HashSet: " + set); 
 
        set.remove("java"); 
        set.remove("4"); 
        set.remove("hello"); 
  
        System.out.println("HashSet after removing elements: " + set); 
    } 
} 