
import java.util.HashSet; 
  
public class add { 
    public static void main(String args[]) 
    { 
        HashSet<String> set = new HashSet<String>(); 
        set.add("Welcome"); 
        set.add("To"); 
        set.add("hello"); 
        set.add("4"); 
        set.add("hi"); 
        System.out.println("HashSet: " + set); 
    } 
} 
