
import java.util.TreeSet; 
  
public class remove{ 
    public static void main(String args[]) 
    { 
        TreeSet<String> tree = new TreeSet<String>(); 
        tree.add("abc"); 
        tree.add("1"); 
        tree.add("bca"); 
        tree.add("cba");  
        System.out.println("TreeSet: " + tree); 
        tree.remove("1");  
        System.out.println("New TreeSet: " + tree); 
    } 
} 