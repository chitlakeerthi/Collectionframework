
import java.util.TreeSet; 
  
public class size { 
    public static void main(String args[]) 
    { 
        TreeSet<String> tree = new TreeSet<String>();  
        tree.add("hi");  
        tree.add("iello"); 
        tree.add("how"); 
        tree.add("1"); 
        tree.add("abc"); 
        System.out.println("TreeSet: " + tree); 
        System.out.println("The size of the set is: " + tree.size()); 
    } 
} 