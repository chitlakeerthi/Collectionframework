 
import java.util.TreeSet; 
  
public class add{ 
    public static void main(String args[]) 
    { 
        TreeSet<String> tree = new TreeSet<String>(); 
        tree.add("abc"); 
        tree.add("bca"); 
        tree.add("cba"); 
        tree.add("1"); 
        System.out.println("TreeSet: " + tree); 
    } 
} 
 